package com.example.flutter_ap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
